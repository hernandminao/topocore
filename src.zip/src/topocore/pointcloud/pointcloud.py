"""
topocore.pointcloud.pointcloud
==============================

High-level point cloud container.

A PointCloud is composed of one or more Chunk objects. It provides a
format-independent representation of a point cloud while remaining
agnostic of file formats such as LAS, LAZ, E57 or PLY.

Author
------
Hernán Mina

License
-------
MIT
"""

from __future__ import annotations

from collections.abc import Iterator

from topocore.pointcloud.attributes import PointAttribute
from topocore.pointcloud.chunk import Chunk


class PointCloud:
    """
    High-level point cloud container.
    """

    def __init__(self) -> None:
        """
        Create an empty point cloud.
        """

        self._chunks: list[Chunk] = []

    def __len__(self) -> int:
        """
        Return the total number of points.
        """

        return self.point_count

    def __iter__(self) -> Iterator[Chunk]:
        """
        Iterate over the chunks.
        """

        return iter(self._chunks)

    @property
    def chunk_count(self) -> int:
        """
        Number of chunks.
        """

        return len(self._chunks)

    @property
    def point_count(self) -> int:
        """
        Total number of points.
        """

        return sum(
            chunk.size
            for chunk in self._chunks
        )

    @property
    def is_empty(self) -> bool:
        """
        Return whether the point cloud contains no points.
        """

        return self.point_count == 0

    @property
    def attributes(self) -> frozenset[PointAttribute]:
        """
        Return the union of attributes present in all chunks.
        """

        attributes: set[PointAttribute] = set()

        for chunk in self._chunks:
            attributes.update(chunk.attributes)

        return frozenset(attributes)

        def add_chunk(
        self,
        chunk: Chunk,
    ) -> None:
        """
        Add a chunk to the point cloud.

        Parameters
        ----------
        chunk
            Chunk to add.
        """

        self._chunks.append(chunk)

    def remove_chunk(
        self,
        index: int,
    ) -> Chunk:
        """
        Remove and return the chunk at the given index.

        Parameters
        ----------
        index
            Zero-based chunk index.

        Returns
        -------
        Chunk
            The removed chunk.

        Raises
        ------
        IndexError
            If the index is out of range.
        """

        return self._chunks.pop(index)

    def clear(self) -> None:
        """
        Remove all chunks from the point cloud.
        """

        self._chunks.clear()

    def clone(self) -> "PointCloud":
        """
        Create a deep copy of the point cloud.

        Returns
        -------
        PointCloud
            Independent copy of this point cloud.
        """

        cloned = PointCloud()

        cloned._chunks = [
            chunk.clone()
            for chunk in self._chunks
        ]

        return cloned

        def __getitem__(
        self,
        index: int,
    ) -> Chunk:
        """
        Return the chunk at the given index.

        Parameters
        ----------
        index
            Zero-based chunk index.

        Returns
        -------
        Chunk
            Requested chunk.

        Raises
        ------
        IndexError
            If the index is out of range.
        """

        return self._chunks[index]

    def __repr__(self) -> str:
        """
        Return a developer-friendly representation.
        """

        return (
            f"{self.__class__.__name__}("
            f"chunks={self.chunk_count}, "
            f"points={self.point_count}, "
            f"attributes={len(self.attributes)}"
            f")"
        )

    __all__ = [
    "PointCloud",
]        